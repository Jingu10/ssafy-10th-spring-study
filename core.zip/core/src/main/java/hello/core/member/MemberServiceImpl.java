package hello.core.member;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;

@Component
public class MemberServiceImpl implements MemberService {

    private final MemberRepository memberRepository;

    @Autowired // ac.getBean(MemberRepository.class)
    // 이렇게 동작한다고 보면 된다!! @Component에 의해 빈으로 등록된 애들 중
    // MemberRepository에 맞는걸(여기선 메모리 멤버 리포지토리) 찾아서 의존관계 주입!)
    public MemberServiceImpl(MemberRepository memberRepository){
        this.memberRepository = memberRepository;
    }

    @Override
    public void join(Member member) {
        // 오버라이딩에 의해 MemoryMemberRepository의 save가 호출된다
        memberRepository.save(member);
    }

    @Override
    public Member findMember(Long memberId) {
        return memberRepository.findById(memberId);
    }
}
